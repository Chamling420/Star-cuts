'use client'

import { cn } from '@/lib/utils'

interface StarLogoProps {
  className?: string
  size?: number
  showText?: boolean
}

/**
 * Modern professional logo for Star Cuts Beauty Salon
 * Features a stylized star with elegant curved lines
 */
export function StarLogo({ className, size = 40, showText = false }: StarLogoProps) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        {/* Outer circle ring */}
        <circle cx="50" cy="50" r="46" stroke="url(#roseGradient)" strokeWidth="3" fill="none" />

        {/* Elegant star shape */}
        <path
          d="M50 12 L56.5 35.5 L80 35.5 L61 50.5 L68 74 L50 60 L32 74 L39 50.5 L20 35.5 L43.5 35.5 Z"
          fill="url(#starGradient)"
          stroke="url(#roseGradient)"
          strokeWidth="1.5"
        />

        {/* Curved accent lines suggesting hair flow */}
        <path
          d="M30 78 Q40 85 50 82 Q60 79 70 85"
          stroke="url(#roseGradient)"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M25 85 Q38 92 50 89 Q62 86 75 92"
          stroke="url(#roseGradient)"
          strokeWidth="2"
          strokeLinecap="round"
          fill="none"
          opacity="0.6"
        />

        {/* Small sparkle dots */}
        <circle cx="78" cy="22" r="2" fill="url(#roseGradient)" opacity="0.8" />
        <circle cx="82" cy="28" r="1.2" fill="url(#roseGradient)" opacity="0.5" />

        <defs>
          <linearGradient id="roseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#e11d48" />
            <stop offset="50%" stopColor="#be123c" />
            <stop offset="100%" stopColor="#9f1239" />
          </linearGradient>
          <linearGradient id="starGradient" x1="20%" y1="20%" x2="80%" y2="80%">
            <stop offset="0%" stopColor="#fb7185" />
            <stop offset="50%" stopColor="#e11d48" />
            <stop offset="100%" stopColor="#be123c" />
          </linearGradient>
        </defs>
      </svg>

      {showText && (
        <div className="flex flex-col leading-tight">
          <span className="text-lg font-bold text-gradient">Star Cuts</span>
          <span className="text-[10px] font-medium text-muted-foreground">Beauty Salon</span>
        </div>
      )}
    </div>
  )
}
