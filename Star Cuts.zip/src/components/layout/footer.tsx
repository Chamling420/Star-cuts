'use client'

import {
  Instagram,
  Facebook,
  Twitter,
  Youtube,
  MapPin,
  Phone,
  Mail,
  Clock,
} from 'lucide-react'
import { useAppStore } from '@/store/use-app-store'
import { StarLogo } from '@/components/ui/star-logo'

const quickLinks = [
  { page: 'home' as const, label: 'Home' },
  { page: 'services' as const, label: 'Services' },
  { page: 'products' as const, label: 'Products' },
  { page: 'gallery' as const, label: 'Gallery' },
  { page: 'contact' as const, label: 'Contact' },
]

const serviceLinks = [
  { page: 'services' as const, label: 'Hair', category: 'hair' },
  { page: 'services' as const, label: 'Skin', category: 'skin' },
  { page: 'services' as const, label: 'Makeup', category: 'makeup' },
  { page: 'services' as const, label: 'Nails', category: 'nails' },
]

export function Footer() {
  const { setCurrentPage } = useAppStore()

  return (
    <footer className="mt-auto bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Logo & Tagline */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <StarLogo size={36} />
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">
                  Star Cuts
                </span>
                <span className="text-[10px] font-medium leading-tight text-primary-foreground/70">
                  Beauty Salon
                </span>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-primary-foreground/80">
              Experience luxury hair styling, coloring, skincare, and beauty
              services. Where elegance meets expertise for your perfect look.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/10 transition-colors hover:bg-primary-foreground/20"
                aria-label="Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/10 transition-colors hover:bg-primary-foreground/20"
                aria-label="Facebook"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/10 transition-colors hover:bg-primary-foreground/20"
                aria-label="Twitter"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/10 transition-colors hover:bg-primary-foreground/20"
                aria-label="YouTube"
              >
                <Youtube className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="flex flex-col gap-2">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => setCurrentPage(link.page)}
                    className="text-sm text-primary-foreground/80 transition-colors hover:text-primary-foreground"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider">
              Services
            </h3>
            <ul className="flex flex-col gap-2">
              {serviceLinks.map((link) => (
                <li key={link.category}>
                  <button
                    onClick={() => setCurrentPage(link.page)}
                    className="text-sm text-primary-foreground/80 transition-colors hover:text-primary-foreground"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider">
              Contact Info
            </h3>
            <ul className="flex flex-col gap-3">
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary-foreground/60" />
                <span className="text-sm text-primary-foreground/80">
                  Lazimpat, Kathmandu
                  <br />
                  Nepal
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 shrink-0 text-primary-foreground/60" />
                <a
                  href="tel:+97714567890"
                  className="text-sm text-primary-foreground/80 transition-colors hover:text-primary-foreground"
                >
+977-01-4567890
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 shrink-0 text-primary-foreground/60" />
                <a
                  href="mailto:hello@starcuts.com"
                  className="text-sm text-primary-foreground/80 transition-colors hover:text-primary-foreground"
                >
                  hello@starcuts.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-primary-foreground/60" />
                <span className="text-sm text-primary-foreground/80">
                  Mon-Fri: 9am - 8pm
                  <br />
                  Sat: 9am - 6pm
                  <br />
                  Sun: 10am - 5pm
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright Bar */}
      <div className="border-t border-primary-foreground/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 sm:flex-row sm:px-6 lg:px-8">
          <p className="text-xs text-primary-foreground/60">
            &copy; {new Date().getFullYear()} Star Cuts Beauty Salon. All rights
            reserved.
          </p>
          <p className="text-xs text-primary-foreground/60">
            Crafted with passion for beauty
          </p>
        </div>
      </div>
    </footer>
  )
}
