'use client'

import { useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useAppStore } from '@/store/use-app-store'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { AuthDialog } from '@/components/auth/auth-dialog'
import HomePage from '@/components/pages/home-page'
import { AboutPage } from '@/components/pages/about-page'
import { ServicesPage } from '@/components/pages/services-page'
import { ProductsPage } from '@/components/pages/products-page'
import { GalleryPage } from '@/components/pages/gallery-page'
import { ContactPage } from '@/components/pages/contact-page'
import { BookingPage } from '@/components/pages/booking-page'
import AdminPanel from '@/components/pages/admin-panel'
import SuperAdminPanel from '@/components/pages/super-admin-panel'

const pageComponents: Record<string, React.ComponentType> = {
  home: HomePage,
  about: AboutPage,
  services: ServicesPage,
  products: ProductsPage,
  gallery: GalleryPage,
  contact: ContactPage,
  booking: BookingPage,
  admin: AdminPanel,
  superadmin: SuperAdminPanel,
}

export default function Home() {
  const { currentPage, setCurrentPage } = useAppStore()

  // Sync hash-based routing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home'
      if (['home', 'about', 'services', 'products', 'gallery', 'contact', 'booking', 'admin', 'superadmin'].includes(hash)) {
        setCurrentPage(hash as any)
      }
    }

    // Set initial page from hash
    const initialHash = window.location.hash.replace('#', '')
    if (initialHash && ['home', 'about', 'services', 'products', 'gallery', 'contact', 'booking', 'admin', 'superadmin'].includes(initialHash)) {
      // Use store directly to avoid double-set
      useAppStore.setState({ currentPage: initialHash as any })
    }

    window.addEventListener('hashchange', handleHashChange)
    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [])

  const PageComponent = pageComponents[currentPage] || HomePage

  return (
    <>
      <Header />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
          >
            <PageComponent />
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
      <AuthDialog />
    </>
  )
}
