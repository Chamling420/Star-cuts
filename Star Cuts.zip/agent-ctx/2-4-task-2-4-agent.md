# Task 2-4 - Currency Replacement, CMS, and Role Permissions

## Task ID: 2-4
## Agent: Task 2-4 Agent

## Summary of Changes

### 1. Currency Symbol Replacement ($ → Rs)
Replaced all "$" currency symbols with "Rs" (Nepali Rupees) across 7 .tsx files:

- **home-page.tsx**: `Rs {service.price}`, `Rs {product.price.toFixed(2)}`
- **services-page.tsx**: `Rs {service.price}`
- **products-page.tsx**: `Rs {product.price.toFixed(2)}`, `Rs {(item.price * item.quantity).toFixed(2)}`, `Rs {cartTotal().toFixed(2)}`
- **booking-page.tsx**: `Rs {service.price.toFixed(2)}`, `Rs {selectedService.price.toFixed(2)}`, `Rs {selectedService?.price.toFixed(2)}`
- **admin-panel.tsx**: `Rs {Number(svc.price).toFixed(2)}`, `Rs {Number(prod.price).toFixed(2)}`, form labels `Price (Rs)`
- **super-admin-panel.tsx**: `Rs {stats?.totalRevenue?.toLocaleString() || '0'}` (2 instances)

### 2. SiteContent Model (Prisma)
Added to `prisma/schema.prisma`:
- Model with id, section, key, value, updatedAt, createdAt
- Unique constraint on [section, key]
- Pushed to database successfully

### 3. CMS API Route
Created `/src/app/api/content/route.ts` with:
- GET: List all content or filter by section query param
- POST: Upsert content by section+key
- PUT: Update content by id
- DELETE: Delete content by id

### 4. CMS Content Seed
Created and ran `prisma/seed-content.ts`:
- Seeded 19 content items across hero, about, contact, footer, testimonials sections

### 5. Role Permission Definitions
Added to `src/types/index.ts`:
- `ROLE_PERMISSIONS` constant with USER, ADMIN, SUPER_ADMIN permission objects
- `RolePermissionKey` type

## Verification
- `bun run lint` passes with no errors
- Dev server running successfully
